package com.autoremoteexample.polio;

import com.journeyapps.barcodescanner.CaptureActivity;

/**
 * Created by Sepehr on 7/1/2017.
 */

public class CaptureActivityPortait extends CaptureActivity {
}
