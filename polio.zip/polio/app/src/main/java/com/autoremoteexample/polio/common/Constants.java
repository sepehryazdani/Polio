package com.autoremoteexample.polio.common;

/**
 * Created by Unknown_ on 5/28/2017.
 */

public class Constants {

    //constants in secondary concentration method
    public static  final String LAB_CONCENTRATION_METHOD_SKIMMED_MILK = "Skimmed Milk";
    public static final String LAB_CONCENTRATION_METHOD_PEG = "PEG";
//    public static final int LAB_CONCENTRATION_METHOD_OTHER = ;
    public static final int FIELD_RAINY_YESTERDAY=1;
    public static final int FIELD_NOT_RAINY_YESTERDAY=0;
    public static final int FIELD_RAINY_TODAY=1;
    public static final int FIELD_NOT_RAINY_TODAY=0;
    public static final int FIELD_SHIPPED_COLD=1;
    public static final int FIELD_SHIPPED_NOT_COLD=0;
    public static final int TEMP_LOGGER_INCLUDED=1;
    public static final int TEMP_LOGGER_NOT_INCLUDED=0;
    public static final int SAMPLE_COLD=1;
    public static final int SAMPLE_NOT_COLD=0;
    public static final int NOT_SELECTED_STATE = -1; // init step for temp not included and included in revieved in LAB


    public static final String FILE_NAME = "data1.bin";

}
