package com.autoremoteexample.polio.model;

/**
 * Created by Unknown_ on 5/26/2017.
 */

public class LabInfo {

    private int tempDegree = 0;

    public int getTempDegree() {
        return tempDegree;
    }

    public void setTempDegree(int tempDegree) {
        this.tempDegree = tempDegree;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
